let config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Sakshi@0824',
    'database': 'books',
}

module.exports = config;